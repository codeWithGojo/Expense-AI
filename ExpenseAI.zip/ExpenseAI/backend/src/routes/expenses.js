const express = require("express");
const prisma = require("../prismaClient");
const requireAuth = require("../middleware/auth");

const router = express.Router();
router.use(requireAuth);

// List (with optional search/category filter)
router.get("/", async (req, res) => {
  const { search, category } = req.query;
  const expenses = await prisma.expense.findMany({
    where: {
      userId: req.userId,
      ...(category ? { category } : {}),
      ...(search ? { note: { contains: search } } : {}),
    },
    orderBy: { date: "desc" },
  });
  res.json(expenses);
});

router.post("/", async (req, res) => {
  const { amount, category, note, date } = req.body;
  if (!amount || !category) {
    return res.status(400).json({ error: "amount and category are required" });
  }
  const expense = await prisma.expense.create({
    data: {
      amount: parseFloat(amount),
      category,
      note,
      date: date ? new Date(date) : undefined,
      userId: req.userId,
    },
  });
  res.status(201).json(expense);
});

router.put("/:id", async (req, res) => {
  const { id } = req.params;
  const existing = await prisma.expense.findUnique({ where: { id } });
  if (!existing || existing.userId !== req.userId) {
    return res.status(404).json({ error: "Expense not found" });
  }
  const { amount, category, note, date } = req.body;
  const updated = await prisma.expense.update({
    where: { id },
    data: {
      ...(amount !== undefined ? { amount: parseFloat(amount) } : {}),
      ...(category !== undefined ? { category } : {}),
      ...(note !== undefined ? { note } : {}),
      ...(date !== undefined ? { date: new Date(date) } : {}),
    },
  });
  res.json(updated);
});

router.delete("/:id", async (req, res) => {
  const { id } = req.params;
  const existing = await prisma.expense.findUnique({ where: { id } });
  if (!existing || existing.userId !== req.userId) {
    return res.status(404).json({ error: "Expense not found" });
  }
  await prisma.expense.delete({ where: { id } });
  res.status(204).send();
});

module.exports = router;
