const express = require("express");
const prisma = require("../prismaClient");
const requireAuth = require("../middleware/auth");

const router = express.Router();
router.use(requireAuth);

router.get("/", async (req, res) => {
  const goals = await prisma.goal.findMany({ where: { userId: req.userId } });
  res.json(goals);
});

router.post("/", async (req, res) => {
  const { title, targetAmount, deadline } = req.body;
  if (!title || !targetAmount) {
    return res.status(400).json({ error: "title and targetAmount are required" });
  }
  const goal = await prisma.goal.create({
    data: {
      title,
      targetAmount: parseFloat(targetAmount),
      deadline: deadline ? new Date(deadline) : undefined,
      userId: req.userId,
    },
  });
  res.status(201).json(goal);
});

router.put("/:id", async (req, res) => {
  const { id } = req.params;
  const existing = await prisma.goal.findUnique({ where: { id } });
  if (!existing || existing.userId !== req.userId) {
    return res.status(404).json({ error: "Goal not found" });
  }
  const { savedAmount, title, targetAmount, deadline } = req.body;
  const updated = await prisma.goal.update({
    where: { id },
    data: {
      ...(savedAmount !== undefined ? { savedAmount: parseFloat(savedAmount) } : {}),
      ...(title !== undefined ? { title } : {}),
      ...(targetAmount !== undefined ? { targetAmount: parseFloat(targetAmount) } : {}),
      ...(deadline !== undefined ? { deadline: new Date(deadline) } : {}),
    },
  });
  res.json(updated);
});

router.delete("/:id", async (req, res) => {
  const { id } = req.params;
  const existing = await prisma.goal.findUnique({ where: { id } });
  if (!existing || existing.userId !== req.userId) {
    return res.status(404).json({ error: "Goal not found" });
  }
  await prisma.goal.delete({ where: { id } });
  res.status(204).send();
});

module.exports = router;
