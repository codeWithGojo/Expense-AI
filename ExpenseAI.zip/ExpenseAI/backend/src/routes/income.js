const express = require("express");
const prisma = require("../prismaClient");
const requireAuth = require("../middleware/auth");

const router = express.Router();
router.use(requireAuth);

router.get("/", async (req, res) => {
  const incomes = await prisma.income.findMany({
    where: { userId: req.userId },
    orderBy: { date: "desc" },
  });
  res.json(incomes);
});

router.post("/", async (req, res) => {
  const { amount, source, date } = req.body;
  if (!amount || !source) {
    return res.status(400).json({ error: "amount and source are required" });
  }
  const income = await prisma.income.create({
    data: {
      amount: parseFloat(amount),
      source,
      date: date ? new Date(date) : undefined,
      userId: req.userId,
    },
  });
  res.status(201).json(income);
});

router.delete("/:id", async (req, res) => {
  const { id } = req.params;
  const existing = await prisma.income.findUnique({ where: { id } });
  if (!existing || existing.userId !== req.userId) {
    return res.status(404).json({ error: "Income not found" });
  }
  await prisma.income.delete({ where: { id } });
  res.status(204).send();
});

module.exports = router;
