import React, { useEffect, useState } from "react";
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip } from "recharts";
import api from "../api/client";

const COLORS = ["#2563eb", "#60a5fa", "#93c5fd", "#1e40af", "#3b82f6", "#bfdbfe"];

export default function Dashboard({ onLogout }) {
  const [expenses, setExpenses] = useState([]);
  const [insights, setInsights] = useState(null);
  const [form, setForm] = useState({ amount: "", category: "", note: "" });
  const [chatInput, setChatInput] = useState("");
  const [chatReply, setChatReply] = useState("");

  async function load() {
    const [{ data: exp }, { data: ins }] = await Promise.all([
      api.get("/expenses"),
      api.get("/ai/insights"),
    ]);
    setExpenses(exp);
    setInsights(ins);
  }

  useEffect(() => {
    load();
  }, []);

  async function addExpense(e) {
    e.preventDefault();
    if (!form.amount || !form.category) return;
    await api.post("/expenses", form);
    setForm({ amount: "", category: "", note: "" });
    load();
  }

  async function askAI(e) {
    e.preventDefault();
    if (!chatInput) return;
    const { data } = await api.post("/ai/chat", { message: chatInput });
    setChatReply(data.reply);
    setChatInput("");
  }

  const byCategory = expenses.reduce((acc, e) => {
    acc[e.category] = (acc[e.category] || 0) + e.amount;
    return acc;
  }, {});
  const chartData = Object.entries(byCategory).map(([name, value]) => ({ name, value }));

  return (
    <div className="min-h-screen bg-slate-50 p-6 max-w-5xl mx-auto">
      <header className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold text-brand-700">ExpenseAI Dashboard</h1>
        <button onClick={onLogout} className="text-sm text-slate-500 hover:text-red-500">
          Log out
        </button>
      </header>

      <div className="grid md:grid-cols-2 gap-6">
        <section className="bg-white rounded-2xl shadow p-5">
          <h2 className="font-semibold mb-3">Add expense</h2>
          <form onSubmit={addExpense} className="flex gap-2 flex-wrap">
            <input
              className="border rounded-lg px-3 py-2 flex-1 min-w-[100px]"
              placeholder="Amount"
              type="number"
              value={form.amount}
              onChange={(e) => setForm({ ...form, amount: e.target.value })}
            />
            <input
              className="border rounded-lg px-3 py-2 flex-1 min-w-[100px]"
              placeholder="Category"
              value={form.category}
              onChange={(e) => setForm({ ...form, category: e.target.value })}
            />
            <input
              className="border rounded-lg px-3 py-2 flex-1 min-w-[100px]"
              placeholder="Note (optional)"
              value={form.note}
              onChange={(e) => setForm({ ...form, note: e.target.value })}
            />
            <button className="bg-brand-600 hover:bg-brand-700 text-white rounded-lg px-4 py-2">
              Add
            </button>
          </form>

          <ul className="mt-4 divide-y">
            {expenses.map((e) => (
              <li key={e.id} className="py-2 flex justify-between text-sm">
                <span>{e.category}{e.note ? ` — ${e.note}` : ""}</span>
                <span className="font-medium">{e.amount.toFixed(2)}</span>
              </li>
            ))}
            {expenses.length === 0 && <p className="text-slate-400 text-sm py-2">No expenses yet.</p>}
          </ul>
        </section>

        <section className="bg-white rounded-2xl shadow p-5">
          <h2 className="font-semibold mb-3">Spend by category</h2>
          {chartData.length > 0 ? (
            <ResponsiveContainer width="100%" height={220}>
              <PieChart>
                <Pie data={chartData} dataKey="value" nameKey="name" outerRadius={80} label>
                  {chartData.map((_, i) => (
                    <Cell key={i} fill={COLORS[i % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          ) : (
            <p className="text-slate-400 text-sm">Add expenses to see the chart.</p>
          )}
        </section>

        <section className="bg-white rounded-2xl shadow p-5 md:col-span-2">
          <h2 className="font-semibold mb-3">AI financial coach</h2>
          {insights && (
            <ul className="text-sm space-y-1 mb-4 text-slate-600">
              {insights.tips.map((t, i) => (
                <li key={i}>• {t}</li>
              ))}
            </ul>
          )}
          <form onSubmit={askAI} className="flex gap-2">
            <input
              className="border rounded-lg px-3 py-2 flex-1"
              placeholder="Ask about your spending or goals..."
              value={chatInput}
              onChange={(e) => setChatInput(e.target.value)}
            />
            <button className="bg-brand-600 hover:bg-brand-700 text-white rounded-lg px-4 py-2">
              Ask
            </button>
          </form>
          {chatReply && <p className="mt-3 text-sm bg-brand-50 rounded-lg p-3">{chatReply}</p>}
        </section>
      </div>
    </div>
  );
}
